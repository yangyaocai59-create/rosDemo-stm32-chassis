from pathlib import Path
import json,subprocess,time
w=Path('/home/jetson/rosdemo_jetson_ws');p=Path(__file__).parent
state=json.loads((p/'uart_state.json').read_text());assert state['ready'] and not state.get('error') and state['uart_receive_age_s']<2
context=json.loads((p/'context.json').read_text());context['motion_capture_base_log_offset']=Path(context['base_log']).stat().st_size
commands=[['/usr/bin/python3',str(w/'tools/localization_observer.py'),'--duration','300','--output',str(p/'motion.json'),'--stop-file',str(p/'stop_capture'),'--sensor-depth','200','--checkpoint-seconds','2','--checkpoint-tail','400'],[str(w/'logs/navigation/tf_static_review_20261019/build/input_observer'),'300',str(p/'native_inputs')]]
context['processes']=[]
for name,command in zip(['motion','native'],commands):
 with (p/(name+'_observer.log')).open('w') as f:proc=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 context['processes'].append({'name':name,'pid':proc.pid,'command':command})
context['capture_started_wall_s']=time.time();(p/'capture_session.json').write_text(json.dumps(context,indent=2)+'\n')
print(json.dumps(context['processes'],indent=2))
