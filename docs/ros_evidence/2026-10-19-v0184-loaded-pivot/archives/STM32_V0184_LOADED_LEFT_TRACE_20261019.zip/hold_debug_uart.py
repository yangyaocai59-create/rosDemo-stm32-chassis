#!/usr/bin/python3
"""Single UART open across an operator-controlled motion. Never sends velocity."""
import json
import os
from pathlib import Path
import re
import time
import serial

ROOT = Path(__file__).resolve().parent
LOG = Path(json.loads((ROOT/'context.json').read_text())['base_log'])
PORT = '/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0'
STATUS = re.compile(r'\[INFO\] \[([\d.]+)\].*STATUS t=(\d+) state=(\w+)\(\d+\) fault=(\w+)\(\d+\) controller_fault=(\w+)\(\d+\).*requested=(-?\d+)mm/s,(-?\d+)mrad/s')
WHEEL = re.compile(r'R4 WHEEL t=(\d+).*cps=\[([^]]+)\]')

def save(name, value):
    temp = ROOT/(name+'.tmp')
    temp.write_text(json.dumps(value, indent=2)+'\n')
    temp.replace(ROOT/name)

def telemetry():
    with LOG.open('rb') as f:
        f.seek(max(0, LOG.stat().st_size-48000))
        text = f.read().decode(errors='replace')
    status = list(STATUS.finditer(text))[-1]
    wheels = list(WHEEL.finditer(text))[-1]
    return dict(host_s=float(status[1]), mcu_ms=int(status[2]), state=status[3],
                fault=status[4], controller_fault=status[5], vx=int(status[6]),
                wz=int(status[7]), wheel_mcu_ms=int(wheels[1]),
                cps=list(map(int, wheels[2].split(','))))

def stopped(t):
    return (time.time()-t['host_s'] < 3 and t['state']=='IDLE' and
            t['fault']==t['controller_fault']=='NONE' and
            t['vx']==t['wz']==0 and t['cps']==[0,0,0,0])

before = telemetry()
assert stopped(before), before
assert json.loads((ROOT/'before_uart_static.json').read_text())['cmd_publishers']==0
s = serial.Serial(port=None, baudrate=115200, timeout=.05, write_timeout=.5,
                  dsrdtr=False, rtscts=False, exclusive=True)
s.dtr=False; s.rts=False; s.port=PORT
state=dict(pid=os.getpid(), port=PORT, before=before, ready=False, tx=[],
           scope='Only UART byte t may be sent, after externally confirmed stop. No velocity/reset/calibration commands.',
           opened_wall_s=time.time(), resets=0, motion_seen=False, bytes=0)
raw=bytearray(); last_rx=time.monotonic(); next_check=0.; last_mcu=before['mcu_ms']
opened=time.monotonic(); ready_at=None; idle_since=None; dump_started=None; trace_offset=None
try:
    s.open()
    with (ROOT/'uart_rx.bin').open('wb') as binary, (ROOT/'uart.log').open('w') as textlog, (ROOT/'uart_chunks.jsonl').open('w') as chunks:
        while True:
            data=s.read(4096)
            if data:
                last_rx=time.monotonic(); raw.extend(data)
                binary.write(data); binary.flush()
                textlog.write(data.decode('utf-8',errors='replace')); textlog.flush()
                chunks.write(json.dumps({'host_s':time.time(),'bytes':len(data)})+'\n');chunks.flush()
                state['bytes']=len(raw)
            now=time.monotonic()
            if now < next_check:continue
            next_check=now+.5
            t=telemetry();state['latest_status']=t
            if t['mcu_ms'] < last_mcu:
                state['resets']+=1
                if state['ready']:
                    state['error']='MCU restarted after UART ready; invalidate trial and do not dump'
                    save('aborted.json',state)
            last_mcu=t['mcu_ms']
            if stopped(t):
                if idle_since is None:idle_since=now
            else:idle_since=None
            fresh_uart=now-last_rx<2
            if not state['ready'] and now-opened>=10 and stopped(t) and fresh_uart and t['mcu_ms']>=5000:
                state['ready']=True;ready_at=now
                state['ready_mcu_ms']=t['mcu_ms'];state['ready_wall_s']=time.time()
                save('uart_ready.json',state);print('UART_READY: descriptor remains open; no movement commanded.',flush=True)
            if state['ready'] and time.time()-t['host_s']<3 and t['state']=='ACTIVE':
                state['motion_seen']=True
                if t['vx']!=0 or t['wz']!=200:
                    state['error']='Unexpected ACTIVE command for this one-left trial'
                    save('aborted.json',state)
            req=ROOT/'dump.request.json'
            if req.exists() and dump_started is None:
                request=json.loads(req.read_text())
                assert request['user_confirmed_motion_stopped_and_teleop_exited'] is True
                assert request['actual_cmd_vel_publishers']==0
                assert state['ready'] and state['motion_seen'] and 'error' not in state
                assert stopped(t) and idle_since is not None and now-idle_since>=1
                assert fresh_uart
                assert s.write(b't')==1
                state['tx'].append({'host_s':time.time(),'hex':'74','meaning':'idle-only cached motion trace dump'})
                dump_started=now;trace_offset=len(raw);print('DUMP_REQUESTED: keeping same UART descriptor open.',flush=True)
            if dump_started is not None and 'dump_result' not in state:
                trace=raw[trace_offset:].decode('utf-8',errors='replace')
                complete='TRACE END' in trace
                unavailable='TRACE unavailable' in trace
                if complete or unavailable or now-dump_started>45:
                    state['dump_result']={'complete':complete,'unavailable':unavailable,
                      'headers':len(re.findall(r'TRACE t=',trace)),
                      'wheel_lines':len(re.findall(r'TRACE (?:LF|LR|RF|RR) dc=',trace)),
                      'elapsed_s':now-dump_started,'rx_byte_start':trace_offset}
                    save('dump_result.json',state);print(json.dumps(state['dump_result']),flush=True)
            state['uart_receive_age_s']=now-last_rx
            save('uart_state.json',state)
            if (ROOT/'close.request').exists():
                assert stopped(t),'Refusing requested close while vehicle is not stopped'
                break
            if now-opened>1200 and stopped(t):
                state['lease_expired']=True;break
except Exception as exc:
    state['error']=repr(exc);save('uart_error.json',state);print('UART_CAPTURE_ERROR: '+repr(exc),flush=True)
finally:
    s.close();state['closed_wall_s']=time.time();save('uart_closed.json',state)
