"""Save the static-validated driver checkpoint without commanding motion."""
import datetime
import hashlib
import json
import math
import shutil
import tarfile
import time
from pathlib import Path

import rclpy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, LaserScan
from tf2_msgs.msg import TFMessage
from rclpy.qos import qos_profile_sensor_data

workspace = Path('/home/jetson/rosdemo_jetson_ws')
base = Path('/home/jetson/rosdemo_checkpoints')
evidence = Path(__file__).parent
old = Path((base/'active_checkpoint_path.txt').read_text().strip())
manifest = json.loads((old / 'manifest.json').read_text())

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

changed = [row['path'] for row in manifest['critical_files']
           if sha(Path(row['path'])) != row['sha256']]
assert changed == [], changed
rclpy.init()
node = rclpy.create_node('accepted_checkpoint_capture')
counts = {'wheel': 0, 'scan': 0, 'imu': 0}
transforms = {}
max_speed = [0.0]
start = time.monotonic() + 2

def receive(key, msg):
    if time.monotonic() < start:
        return
    counts[key] += 1
    if key == 'wheel':
        max_speed[0] = max(max_speed[0], abs(msg.twist.twist.linear.x),
                           abs(msg.twist.twist.angular.z))

def tf_callback(msg):
    for transform in msg.transforms:
        edge = (transform.header.frame_id, transform.child_frame_id)
        if edge in [('map', 'odom'), ('odom', 'base_footprint')]:
            transforms[edge] = transform.transform

subscriptions = [
    node.create_subscription(Odometry, '/wheel/odometry', lambda m: receive('wheel', m), 50),
    node.create_subscription(LaserScan, '/scan', lambda m: receive('scan', m), qos_profile_sensor_data),
    node.create_subscription(Imu, '/imu/data_raw', lambda m: receive('imu', m), qos_profile_sensor_data),
    node.create_subscription(TFMessage, '/tf', tf_callback, 100),
]
while time.monotonic() - start < 5:
    rclpy.spin_once(node, timeout_sec=.05)
publishers = node.count_publishers('/cmd_vel')
node.destroy_node()
rclpy.try_shutdown()
assert publishers == 0 and max_speed[0] == 0.0 and min(counts.values()) >= 30

def yaw(q):
    return math.atan2(2*(q.w*q.z + q.x*q.y), 1-2*(q.y*q.y + q.z*q.z))

a = transforms[('map', 'odom')]
b = transforms[('odom', 'base_footprint')]
t = yaw(a.rotation)
pose = [a.translation.x + math.cos(t)*b.translation.x - math.sin(t)*b.translation.y,
        a.translation.y + math.sin(t)*b.translation.x + math.cos(t)*b.translation.y,
        t + yaw(b.rotation)]


result=json.loads((evidence/'combined_result.json').read_text())
assert result['trace']['trace_frames']==127 and result['no_additional_reset_between_ready_motion_and_dump']
now=datetime.datetime.now().astimezone();root=base/now.strftime('%Y%m%d_%H%M%S');root.mkdir()
state=json.loads((old/'checkpoint.json').read_text())
state.update({'created_at':now.isoformat(),'previous_checkpoint':str(old),'last_map_pose_x_y_yaw':pose,
 'stationary_samples':counts,'cmd_vel_publishers':publishers,
 'accepted_actual_loaded_left_trace':{'evidence':str(evidence),'operator_actions':2,'trace_corresponds_to_action':2,'complete_trace_frames':127,
  'direction_stop_pass':True,'angular_speed_tracking_pass':False,'actual_wheel_target_cps':[-160,-160,160,160],
  'steady_mean_filtered_cps':[-24.9732142857,-44.4553571429,23.6339285714,80.2232142857],
  'no_reset_after_uart_ready_through_dump':True,'uart_closed_after_stopping':True},
 'motion_acceptance_scope':'Forward starts, left direction and release-to-stop passed. Actual low-speed ground-loaded wheel tracking inadequate; complete internal trace obtained. Further motion/Nav2 deferred for load/controller/drive review, no firmware change made.',
 'current_session_has_status_timeout':True,
 'status_timeout_context':'UART insertion/open preparation involved USB loss/PIN RESET and expected fail-closed STOP/reconnect. No STATUS/output errors during captured motion/dump. Historical session log retains all events.',
 'pending':['Review actual target/raw/filtered/PWM/FF/P/I trace with STM32 engineer and mechanical/drive load; decide minimal correction before more motion',
  'Debug UART open remains associated with PIN RESET despite user-reported TX/RX/GND-only wiring; keep independent from low-speed control issue',
  'After correction/review, controlled response check, ROS restart motion recovery and Nav2 short-goal regression; no autonomous exploration yet'],
 'report':str(workspace/'docs/JETSON_LOADED_LEFT_TRACE_REVIEW_2026-10-19.md')})
(root/'checkpoint.json').write_text(json.dumps(state,indent=2)+'\n')
manifest['created_at']=now.isoformat();(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report=Path(state['report']);text=report.read_text()
text+=f'\n最新停车检查点：`{root}`，36个关键文件保持原版本。静止采样{counts}，实际/cmd_vel发布者{publishers}；保存的是地图估计位姿，不是独立真值。调试口已关闭。\n';report.write_text(text)
entry=workspace/'docs/CONTINUE_TOMORROW.md';text=entry.read_text().replace(str(old),str(root),1)
text=text.replace('[离线核对与调试口事件]', '[实际MCU轮速/PWM采集](JETSON_LOADED_LEFT_TRACE_REVIEW_2026-10-19.md) · [离线核对与调试口事件]',1)
text=text.replace('**新驱动 + UDP 两次前进启停通过；短左转方向/停车/RViz 通过，但转速响应待查，暂停后续运动与 Nav2 实车目标**', '**两次前进启停及左转方向/停车已通过；已取得第二次地面左转的完整127帧内部trace，实际target±160cps但四轮明显欠速，暂停后续运动与Nav2实车目标，等待负载/控制分析**')
a=text.index('先确认地图/激光/TF 对齐，不开遥控、不点目标。')
text=text[:a]+'''先确认地图/激光/TF 对齐，不开遥控、不点目标。内部trace已完整获取：requested/applied200mrad/s、target±160cps，平均实测约−25/−44/+24/+80cps。下一步直接用已有CSV/UART/ROS证据分析负载下前馈、PI、启动补偿与机械/驱动条件，不再盲目追加转圈或修改轮距。UART采用静止先打开并保持fd完成采集，现已关闭；开口关联PIN RESET的根因仍未解决，暂不反复开口。

[实际数据交接说明](STM32_LOADED_PIVOT_TRACE_HANDOFF_2026-10-19.md)。没有修改/烧录固件，也没有上传仓库。关机前先正常停止机器人会话，确认停车及串口释放，再在Jetson执行 `sudo shutdown -h now`，待关机后断电。未配置开机自启。
'''
entry.write_text(text)
(root/'map').mkdir()
for suffix in ['.pgm','.yaml','.posegraph','.data']:
 source=Path(state['map_prefix']+suffix);target=root/'map'/source.name;shutil.copy2(source,target);assert sha(source)==sha(target)
for source in [entry,report,workspace/'docs/STM32_LOADED_PIVOT_TRACE_HANDOFF_2026-10-19.md',evidence/'combined_result.json',evidence/'capture_session.json']:
 shutil.copy2(source,root/source.name)
shutil.copy2(old/'versions.txt',root/'versions.txt');(root/'runtime').mkdir()
for source in (old/'runtime').iterdir():
 if source.is_file():shutil.copy2(source,root/'runtime'/source.name)
for source in [report,workspace/'docs/STM32_LOADED_PIVOT_TRACE_HANDOFF_2026-10-19.md']:
 shutil.copy2(source,evidence/source.name)
def exclude(info):
 return None if any(x in ('__pycache__','.git','.pytest_cache') for x in Path(info.name).parts) else info
for name,paths in [('workspace_sources.tar.gz',['src','tools','docs','README.md','logs/COLCON_IGNORE']),('navigation_evidence.tar.gz',['logs/navigation'])]:
 with tarfile.open(root/name,'w:gz') as archive:
  for file in paths:archive.add(workspace/file,arcname=file,filter=exclude)
 with tarfile.open(root/name,'r:gz') as archive:
  for item in archive:
   if item.isfile():
    stream=archive.extractfile(item)
    while stream.read(1024*1024):pass
(root/'SHA256SUMS').write_text(''.join(f'{sha(f)}  {f.relative_to(root)}\n' for f in sorted(root.rglob('*')) if f.is_file()))
pointer=base/'active_checkpoint_path.txt';temp=pointer.with_suffix('.txt.tmp');temp.write_text(str(root)+'\n');temp.replace(pointer)
print(json.dumps({'checkpoint':str(root),'map_pose':pose,'stationary_samples':counts,'cmd_publishers':publishers,'critical_files':len(manifest['critical_files']),'trace_frames':127,'angular_speed_tracking_pass':False},indent=2))
