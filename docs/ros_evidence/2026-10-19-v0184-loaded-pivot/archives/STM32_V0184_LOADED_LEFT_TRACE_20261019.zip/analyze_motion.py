from pathlib import Path
import collections,json,math,sys,re
P=Path(__file__).resolve().parent;sys.path.insert(0,'/home/jetson/rosdemo_jetson_ws/tools')
from analyze_imu_motion_trial import integrate
rows=collections.defaultdict(list)
for line in (P/'motion.jsonl').open():
 r=json.loads(line);rows[r['topic']].append(r)
cmd=rows['/cmd_vel'];changes=[];last=None
for r in cmd:
 v=(r['vx'],r['wz'])
 if v!=last:changes.append(r);last=v
segments=[]
for a in changes:
 if a['vx']==0 and a['wz']==0:continue
 b=next((r for r in changes if r['stamp']>a['stamp'] and r['vx']==r['wz']==0),None)
 assert b,'No stop found'
 lo=a['stamp']-.2;hi=b['stamp']+1
 js=[r for r in rows['/joint_states'] if a['stamp']<=r['stamp']<=b['stamp']]
 nz=[r for r in cmd if a['stamp']<=r['stamp']<b['stamp']]
 duration=b['stamp']-a['stamp']
 segments.append({'command_start_ros_s':a['stamp'],'command_stop_ros_s':b['stamp'],'command_duration_s':duration,
  'vx_m_s':a['vx'],'wz_rad_s':a['wz'],'command_integral_deg':math.degrees(a['wz']*duration),
  'common_measurement_window_ros_s':[lo,hi],
  'estimated_angles_deg':{t:math.degrees(integrate(rows[t],k,lo,hi)) for t,k in [('/imu/data_raw','gyro_z'),('/wheel/odometry','wz'),('/odom','wz')]},
  'mean_filtered_wheel_cps_LF_LR_RF_RR':[sum(r['velocity'][i] for r in js)/len(js)*1560/(2*math.pi) for i in range(4)],
  'maximum_nonzero_command_receive_gap_s':max(y['stamp']-x['stamp'] for x,y in zip(nz,nz[1:]))})
summary=json.loads((P/'motion.json').read_text())
context=json.loads((P/'capture_session.json').read_text());f=Path(context['base_log'])
with f.open('rb') as log:log.seek(context['motion_capture_base_log_offset']);body=log.read().decode(errors='replace')
(P/'driver_motion_and_dump.log').write_text(body)
result={'segments':segments,'operator_reported_count':2,'captured_command_segments':len(segments),
 'non_left_commands':any(s['vx_m_s']!=0 or s['wz_rad_s']!=.2 for s in segments),
 'driver_errors':[l for l in body.splitlines() if '[ERROR]' in l],
 'status_timeouts':body.count('STATUS telemetry timeout'),'output_faults':body.count('ROS output failed or exceeded'),
 'final_cmd_publishers':summary['publishers']['/cmd_vel'],'final_wheel_vx_wz':[rows['/wheel/odometry'][-1]['vx'],rows['/wheel/odometry'][-1]['wz']],
 'scope':'User performed two manual lefts. No external angle measurement. MCU cache resets at each start; trace must be matched to last motion only.'}
(P/'motion_analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
