// Copyright 2026 Yang
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "rosdemo_base/velocity_command.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <utility>

#include "rosdemo_base/protocol_v1.hpp"

namespace rosdemo_base
{

bool statusAllowsMotion(const protocol_v1::Status & status) noexcept
{
  constexpr std::uint16_t unsafe_flags = 0x008EU;
  constexpr std::uint16_t required_flags = 0x0150U;
  const bool state_allows_motion =
    status.runtime_state == 1U || status.runtime_state == 2U;
  return state_allows_motion && status.runtime_fault == 0U &&
         status.controller_fault == 0U &&
         (status.flags & unsafe_flags) == 0U &&
         (status.flags & required_flags) == required_flags;
}

bool statusIsStopped(const protocol_v1::Status & status) noexcept
{
  return status.runtime_state == 1U && status.requested_linear_x_mm_s == 0 &&
         status.requested_angular_z_mrad_s == 0;
}

VelocityCommandGate::VelocityCommandGate(VelocityCommandConfig config)
: config_(std::move(config))
{
  if (config_.send_period.count() <= 0) {
    throw std::invalid_argument("velocity send period must be positive");
  }
  if (config_.timeout <= config_.send_period ||
    config_.timeout >= std::chrono::milliseconds(250))
  {
    throw std::invalid_argument(
            "velocity timeout must exceed the send period and remain below 250 ms");
  }
  if (!std::isfinite(config_.max_linear_x_m_s) ||
    config_.max_linear_x_m_s <= 0.0 || config_.max_linear_x_m_s > 0.20)
  {
    throw std::invalid_argument("linear velocity limit must be in (0, 0.20] m/s");
  }
  if (!std::isfinite(config_.max_angular_z_rad_s) ||
    config_.max_angular_z_rad_s <= 0.0 || config_.max_angular_z_rad_s > 1.50)
  {
    throw std::invalid_argument("angular velocity limit must be in (0, 1.50] rad/s");
  }
}

void VelocityCommandGate::beginSession()
{
  std::lock_guard<std::mutex> lock(mutex_);
  ready_ = false;
  stop_pending_ = false;
  zero_latched_ = false;
  command_.reset();
  next_send_ = {};
}

void VelocityCommandGate::markSessionReady()
{
  std::lock_guard<std::mutex> lock(mutex_);
  ready_ = true;
  stop_pending_ = false;
  zero_latched_ = false;
  command_.reset();
  next_send_ = {};
}

void VelocityCommandGate::inhibit()
{
  std::lock_guard<std::mutex> lock(mutex_);
  ready_ = false;
  command_.reset();
  zero_latched_ = false;
  stop_pending_ = true;
  next_send_ = {};
}

void VelocityCommandGate::inhibitPreservingFault()
{
  std::lock_guard<std::mutex> lock(mutex_);
  ready_ = false;
  command_.reset();
  zero_latched_ = false;
  stop_pending_ = false;
  next_send_ = {};
}

VelocitySubmitResult VelocityCommandGate::submit(
  double linear_x_m_s,
  double angular_z_rad_s,
  TimePoint reception_time)
{
  std::lock_guard<std::mutex> lock(mutex_);
  if (!std::isfinite(linear_x_m_s) || !std::isfinite(angular_z_rad_s)) {
    ready_ = false;
    command_.reset();
    zero_latched_ = false;
    stop_pending_ = true;
    next_send_ = {};
    return VelocitySubmitResult::kInvalid;
  }
  if (!ready_) {
    return VelocitySubmitResult::kNotReady;
  }

  const auto limited_linear = std::clamp(
    linear_x_m_s, -config_.max_linear_x_m_s, config_.max_linear_x_m_s);
  const auto limited_angular = std::clamp(
    angular_z_rad_s, -config_.max_angular_z_rad_s, config_.max_angular_z_rad_s);
  const auto linear_mm_s = static_cast<std::int32_t>(std::lround(limited_linear * 1000.0));
  const auto angular_mrad_s = static_cast<std::int32_t>(
    std::lround(limited_angular * 1000.0));

  if (linear_mm_s == 0 && angular_mrad_s == 0) {
    command_.reset();
    if (!zero_latched_) {
      stop_pending_ = true;
      zero_latched_ = true;
    }
    next_send_ = {};
    return VelocitySubmitResult::kAccepted;
  }

  const bool starting = !command_.has_value();
  command_ = Command{linear_mm_s, angular_mrad_s, reception_time};
  zero_latched_ = false;
  if (starting) {
    next_send_ = reception_time;
  }
  return VelocitySubmitResult::kAccepted;
}

VelocityAction VelocityCommandGate::poll(TimePoint now)
{
  std::lock_guard<std::mutex> lock(mutex_);
  if (stop_pending_) {
    stop_pending_ = false;
    return {VelocityActionType::kStop, 0, 0};
  }
  if (!ready_ || !command_) {
    return {};
  }
  if (now - command_->reception_time >= config_.timeout) {
    command_.reset();
    zero_latched_ = true;
    next_send_ = {};
    return {VelocityActionType::kStop, 0, 0};
  }
  if (now < next_send_) {
    return {};
  }

  next_send_ += config_.send_period;
  if (next_send_ <= now) {
    next_send_ = now + config_.send_period;
  }
  return {
    VelocityActionType::kVelocity,
    command_->linear_x_mm_s,
    command_->angular_z_mrad_s};
}

bool VelocityCommandGate::ready() const
{
  std::lock_guard<std::mutex> lock(mutex_);
  return ready_;
}

}  // namespace rosdemo_base
