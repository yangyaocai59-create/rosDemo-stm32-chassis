#!/usr/bin/env python3
"""Read-only analysis of one operator-controlled motion and RAW v2 capture."""

import argparse
import bisect
import json
import math
from pathlib import Path
import re
import statistics


def interpolate(times, values, t):
    index = bisect.bisect_right(times, t)
    if index == 0 or index == len(times):
        raise ValueError('Requested interval is not covered by measurements')
    a, b = index - 1, index
    return values[a] + (values[b] - values[a]) * (t - times[a]) / (times[b] - times[a])


def integrate(rows, key, lo, hi):
    times = [x['stamp'] for x in rows]
    values = [x[key] for x in rows]
    points = [(lo, interpolate(times, values, lo))]
    points += [(t, v) for t, v in zip(times, values) if lo < t < hi]
    points.append((hi, interpolate(times, values, hi)))
    return sum((a[1] + b[1]) * 0.5 * (b[0] - a[0]) for a, b in zip(points, points[1:]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    parser.add_argument('--action', required=True, choices=('forward', 'left', 'right'))
    args = parser.parse_args()
    r = args.run
    rows = [json.loads(x) for x in (r / 'motion.jsonl').open()]
    raw = [json.loads(x) for x in (r / 'raw_v2_samples.jsonl').open()]
    statuses = []
    pattern = (r'R4 STATUS t=(\d+) state=(\w+)\((\d+)\).*?'
               r'requested=(-?\d+)mm/s,(-?\d+)mrad/s')
    for line in (r / 'driver.log').read_text().splitlines():
        m = re.search(pattern, line)
        if m:
            statuses.append({'t_ms': int(m[1]), 'state': m[2],
                             'vx_mm_s': int(m[4]), 'wz_mrad_s': int(m[5])})
    active = [x for x in statuses if x['state'] == 'ACTIVE']
    if not active:
        raise ValueError('No ACTIVE status recorded; do not claim a motion test')
    lo_ms, hi_ms = active[0]['t_ms'], active[-1]['t_ms']
    active_raw = [x for x in raw if lo_ms <= x['sample_time_ms'] <= hi_ms]
    anchor = statistics.median(x['stamp_ns'] / 1e9 - x['sample_time_ms'] / 1000
                               for x in active_raw if x['published'])
    lo, hi = anchor + lo_ms / 1000, anchor + hi_ms / 1000
    topics = {t: [x for x in rows if x['topic'] == t] for t in
              ('/imu/data_raw', '/wheel/odometry', '/odom', '/cmd_vel')}
    imu_deg = math.degrees(integrate(topics['/imu/data_raw'], 'gyro_z', lo, hi))
    wheel_deg = math.degrees(integrate(topics['/wheel/odometry'], 'wz', lo, hi))
    cmd = topics['/cmd_vel']
    nonzero = [x for x in cmd if x['vx'] != 0 or x['wz'] != 0]
    motion_cmd = [x for x in cmd if lo <= x['stamp'] <= hi]
    changes = []
    last = None
    for x in cmd:
        value = (x['vx'], x['wz'])
        if value != last:
            changes.append({'received_s': x['received'], 'vx': x['vx'], 'wz': x['wz']})
            last = value
    biases = {tuple(x['bias_milli_raw']) for x in active_raw}
    base_bias = active_raw[-1]['bias_milli_raw']
    later = [x for x in raw if x['sample_time_ms'] > hi_ms and
             x['bias_milli_raw'] != base_bias]
    first_idle = next((x for x in statuses if x['t_ms'] > hi_ms and x['state'] == 'IDLE'), None)
    summary = json.loads((r / 'motion.json').read_text())
    unique = [x for x in raw if x['published']]
    count_steps = [(b['sample_count'] - a['sample_count']) & 0xffffffff
                   for a, b in zip(unique, unique[1:])]
    inside = [x for x in statuses if lo_ms <= x['t_ms'] <= hi_ms]
    tolerance = max(3.0, 0.20 * abs(imu_deg))
    direction_ok = (all(x['vx_mm_s'] > 0 and x['wz_mrad_s'] == 0 for x in active)
                    if args.action == 'forward' else
                    (imu_deg > 0 and wheel_deg > 0 if args.action == 'left' else
                     imu_deg < 0 and wheel_deg < 0))
    result = {
        'action': args.action, 'common_active_source_interval_ms': [lo_ms, hi_ms],
        'active_span_s': (hi_ms - lo_ms) / 1000, 'active_status_samples': len(active),
        'active_raw_samples_including_duplicates': len(active_raw),
        'active_bias_unique_count': len(biases), 'active_bias_milli_raw': sorted(biases),
        'continuous_active_reports': all(x['state'] == 'ACTIVE' for x in inside),
        'imu_integral_deg': imu_deg, 'wheel_wz_integral_deg': wheel_deg,
        'wheel_imu_angle_difference_deg': abs(wheel_deg - imu_deg),
        'screening_tolerance_deg': tolerance,
        'wheel_displacement_m': summary['topics']['/wheel/odometry']['position_delta_m'],
        'cmd_nonzero_samples': len(nonzero), 'command_changes': changes,
        'active_cmd_max_gap_s': max(b['stamp'] - a['stamp']
                                    for a, b in zip(motion_cmd, motion_cmd[1:])),
        'bias_first_change_after_last_active_s':
        (later[0]['sample_time_ms'] - hi_ms) / 1000 if later else None,
        'bias_first_change_after_first_idle_s':
        (later[0]['sample_time_ms'] - first_idle['t_ms']) / 1000 if later and first_idle else None,
        'source_count_nonunit_steps': sum(x != 1 for x in count_steps),
        'publishers': summary['publishers'],
        'scope': 'Operator low-speed trial only; not geometry calibration or navigation acceptance.'}
    protocol = summary['diagnostics_latest']['rosdemo_base/protocol']['values']
    result['protocol_errors'] = {k: int(protocol[k]) for k in (
        'host_crc_errors', 'host_version_errors', 'host_length_errors', 'rejected_ack',
        'malformed_messages', 'unexpected_messages', 'timestamp_regressions',
        'mcu_crc_errors', 'mcu_rx_overflow_packets', 'mcu_dropped_tx_frames')}
    result['checks'] = {
        'active_bias_frozen': len(biases) == 1 and hi_ms - lo_ms >= 1000,
        'continuous_active_reports': result['continuous_active_reports'],
        'direction': direction_ok, 'wheel_imu_angle_screening': abs(wheel_deg - imu_deg) <= tolerance,
        'command_gap_below_200ms': result['active_cmd_max_gap_s'] < 0.2,
        'source_continuity': result['source_count_nonunit_steps'] == 0,
        'protocol_health': all(x == 0 for x in result['protocol_errors'].values()),
        'returned_to_idle': first_idle is not None}
    result['trial_pass'] = all(result['checks'].values())
    (r / 'analysis.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
