"""Read-only short-left response review; no hardware commands."""
import collections,json,math,sys,re,hashlib,subprocess,shutil
from pathlib import Path
p=Path(__file__).parent;w=Path('/home/jetson/rosdemo_jetson_ws')
sys.path.insert(0,str(w/'tools'))
from analyze_imu_motion_trial import integrate
rows=collections.defaultdict(list)
for line in (p/'motion.jsonl').open():
 r=json.loads(line);rows[r['topic']].append(r)
s=json.loads((p/'motion.json').read_text());cmd=rows['/cmd_vel'];changes=[];previous=None
for r in cmd:
 value=(r['vx'],r['wz'])
 if value!=previous:changes.append(r);previous=value
active=[r for r in changes if r['vx']!=0 or r['wz']!=0];assert len(active)==1
start=active[0];stop=next(r for r in changes if r['stamp']>start['stamp'] and r['vx']==0 and r['wz']==0)
lo=start['stamp']-.2;hi=stop['stamp']+1
angles={topic:math.degrees(integrate(rows[topic],key,lo,hi)) for topic,key in [('/imu/data_raw','gyro_z'),('/wheel/odometry','wz'),('/odom','wz')]}
body=(p/'driver.log').read_text();duration=stop['stamp']-start['stamp']
joints=[r for r in rows['/joint_states'] if start['stamp']<=r['stamp']<=stop['stamp']]
means=[sum(r['velocity'][i] for r in joints)/len(joints)*1560/(2*math.pi) for i in range(4)]
wheel_after=[r for r in rows['/wheel/odometry'] if stop['stamp']<=r['stamp']<=stop['stamp']+4]
zero_delay=None
for i,r in enumerate(wheel_after):
 chunk=[x for x in wheel_after[i:] if x['stamp']<=r['stamp']+.25]
 if len(chunk)>=4 and all(abs(x['vx'])<.003 and abs(x['wz'])<.03 for x in chunk):zero_delay=r['stamp']-stop['stamp'];break
nz=[r for r in cmd if r['wz']!=0]
result={'action':'one short left, ground loaded','command_duration_s':duration,'command_wz_rad_s':start['wz'],'command_vx_m_s':start['vx'],
 'command_integral_deg':math.degrees(.2*duration),'common_measurement_window_ros_s':[lo,hi],
 'estimated_angles_deg':angles,'wheel_imu_difference_deg':angles['/wheel/odometry']-angles['/imu/data_raw'],
 'imu_peak_wz_rad_s':max(r['gyro_z'] for r in rows['/imu/data_raw'] if lo<=r['stamp']<=hi),
 'active_command_received_max_gap_s':max(b['stamp']-a['stamp'] for a,b in zip(nz,nz[1:])),
 'measured_mean_wheel_cps_LF_LR_RF_RR':means,'wheel_zero_feedback_delay_s':zero_delay,
 'state_errors':[line for line in body.splitlines() if '[ERROR]' in line],
 'status_timeout_count':body.count('STATUS telemetry timeout'),'output_fault_count':body.count('ROS output failed or exceeded'),
 'final_velocity_publishers':s['publishers']['/cmd_vel'],'final_wheel_vx_wz':[rows['/wheel/odometry'][-1]['vx'],rows['/wheel/odometry'][-1]['wz']],
 'user_feedback':{'left_direction_normal':True,'motion_stop_normal':True,'rviz_aligned':True,'teleop_exited':True},
 'reference_firmware':{'tag':'v0.18.4','commit':'32bc6d22d8eaac9ceb6bc820a06efe1c01099976','command_track_m':.210},
 'ros_odometry_effective_track_m':.395,'inferred_nominal_steady_wheel_target_m_s':.2*.210/2,
 'inferred_nominal_steady_wheel_target_cps':.2*.210/2*1560/(math.pi*.065),
 'direction_stop_pass':bool(angles['/imu/data_raw']>0 and angles['/wheel/odometry']>0 and zero_delay is not None and not s['publishers']['/cmd_vel'] and not any('[ERROR]' in line for line in body.splitlines())),
 'angular_response_acceptance':'PENDING; response substantially below command, do not claim velocity tracking/turning navigation passed',
 'measured_angle_scope':'Gyro integral and wheel/EKF estimates only; no external angular reference',
 'missing_evidence':'No current MCU applied command, wheel target, PWM, FF/P/I or limited trace captured'}
(p/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
ref=Path('/home/jetson/firmware_reference/rosDemo-stm32-chassis-0.18.4');snapshot=p/'firmware_readonly_reference';snapshot.mkdir(exist_ok=True)
files=['Application/Chassis/chassis_config.h','Application/Chassis/chassis_kinematics.c','Application/Chassis/chassis_motion_profile.h','Application/Chassis/chassis_motion_profile.c','Application/Chassis/chassis_controller.c','Application/Chassis/wheel_speed_controller.c','Application/Chassis/wheel_speed_control_config.h','docs/STM32_WHEEL_SPEED_CONTROL_0.18.0.md','Tools/stm32_pivot_trace_test.py']
manifest=[]
for name in files:
 source=ref/name;target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 manifest.append({'path':name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
(snapshot/'reference.json').write_text(json.dumps({'tag':'v0.18.4','commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ref,text=True).strip(),'worktree_status':subprocess.check_output(['git','status','--short'],cwd=ref,text=True),'files':manifest},indent=2)+'\n')
shutil.copy2(w/'src/rosdemo_base/config/base_driver_release.yaml',p/'ros_base_driver_release.yaml')
