/* OFFLINE ONLY: actual runtime + reference test mocks; no physical-plant model. */
#define main ReferenceRuntimeRegressionMain
#include "/home/jetson/firmware_reference/rosDemo-stm32-chassis-0.18.4/Tools/tests/motion/test_runtime_motion.c"
#undef main
int main(void)
{
  puts("sign,t_ms,requested_wz,applied_wz,target_lf,target_lr,target_rf,target_rr,scale");
  for (int sign=-1; sign<=1; sign+=2) {
    Init(0U);
    for (time_ms=10U; time_ms<=2110U; time_ms+=10U) {
      if ((time_ms-10U)%50U==0U)
        assert(ChassisRuntime_SetVelocity(0.0f,0.2f*(float)sign,time_ms));
      ChassisRuntime_Process(time_ms,false);
      ChassisRuntimeStatus s=Status(); ChassisControllerStatus c;
      assert(ChassisController_GetStatus(&c));
      assert(s.state==CHASSIS_RUNTIME_STATE_ACTIVE);
      if (time_ms>=140U) assert(fabsf(s.applied_command.angular_z_rad_s-0.2f*(float)sign)<1e-6f);
      assert(c.targets.scale==1.0f);
      printf("%d,%u,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f\n", sign,(unsigned)time_ms,
        (double)s.requested_command.angular_z_rad_s,(double)s.applied_command.angular_z_rad_s,
        (double)c.targets.counts_per_second[0],(double)c.targets.counts_per_second[1],
        (double)c.targets.counts_per_second[2],(double)c.targets.counts_per_second[3],(double)c.targets.scale);
    }
    ChassisRuntime_Stop(2111U); AssertStopped(CHASSIS_RUNTIME_STOP_EXPLICIT);
  }
  return 0;
}
