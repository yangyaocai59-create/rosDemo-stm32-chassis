"""Read saved trace only. No USB CDC access or velocity commands."""
import json,re,time
from pathlib import Path
import serial
w=Path('/home/jetson/rosdemo_jetson_ws');p=Path((w/'logs/navigation/current_offline_response_review_path.txt').read_text().strip())/'saved_uart_trace';p.mkdir(exist_ok=False)
log=Path('/home/jetson/rosdemo_checkpoints/20261019_185237/resume_20261019_185303/base_ekf.log')
port='/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0'
def status():
 text=log.read_text();lines=[l for l in text.splitlines() if 'R4 STATUS t=' in l]
 line=lines[-1];m=re.search(r'\[INFO\] \[([\d.]+)\].*STATUS t=(\d+) state=(\w+)\(\d+\) fault=(\w+)\(\d+\) controller_fault=(\w+)\(\d+\).*requested=(-?\d+)mm/s,(-?\d+)mrad/s',line)
 assert m,line
 data={'host_s':float(m[1]),'mcu_ms':int(m[2]),'state':m[3],'fault':m[4],'controller_fault':m[5],'vx_mm_s':int(m[6]),'wz_mrad_s':int(m[7]),'line':line}
 assert time.time()-data['host_s']<3 and data['state']=='IDLE' and data['fault']==data['controller_fault']=='NONE' and data['vx_mm_s']==data['wz_mrad_s']==0,data
 return data
before=status();offset=log.stat().st_size
s=serial.Serial(port=None,baudrate=115200,timeout=.05,write_timeout=.5,rtscts=False,dsrdtr=False,exclusive=True)
s.dtr=False;s.rts=False;s.port=port
summary={'scope':'Read existing motion cache only; only transmitted byte is UART t after IDLE+uptime checks. No speed, reset, calibration or USB CDC command.', 'port':port,'baudrate':115200,'dtr':False,'rts':False,'before':before,'driver_log_offset':offset}
raw=bytearray();events=[]
try:
 s.open()
 def collect(seconds,phase):
  end=time.monotonic()+seconds
  while time.monotonic()<end:
   data=s.read(4096)
   if data:
    raw.extend(data);events.append({'host_s':time.time(),'phase':phase,'bytes':len(data)})
    (p/'uart_rx.bin').write_bytes(raw)
    (p/'uart.log').write_text(raw.decode('utf-8',errors='replace'))
 collect(3.,'passive_before_t')
 after_open=status();summary['after_open']=after_open
 assert after_open['mcu_ms']>=before['mcu_ms'],'MCU uptime regressed; no UART command sent'
 summary['passive_bytes']=len(raw)
 # UART t is the reference firmware's idle-only trace dump command.
 assert s.write(b't')==1
 summary['tx']=[{'host_s':time.time(),'hex':'74','meaning':'idle-only saved motion trace dump'}]
 collect(15.,'after_t')
 summary['after_read']=status()
 summary['received_bytes']=len(raw)
 text=raw.decode('utf-8',errors='replace')
 summary['trace_headers']=len(re.findall(r'TRACE t=',text))
 summary['trace_end']='TRACE END' in text
 summary['trace_unavailable']='TRACE unavailable' in text
 summary['new_boot_markers']=[l for l in text.splitlines() if re.search(r'RESET|BOOT|Reset flags',l,re.I)]
except Exception as e:
 summary['error']=repr(e)
finally:
 s.close()
 (p/'uart_rx.bin').write_bytes(raw);(p/'uart.log').write_text(raw.decode('utf-8',errors='replace'))
 (p/'rx_events.json').write_text(json.dumps(events,indent=2)+'\n')
 (p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 with log.open('rb') as f:f.seek(offset);(p/'driver_during_uart.log').write_bytes(f.read())
 print(json.dumps(summary,indent=2))
