from pathlib import Path
import bisect,collections,ctypes,csv,json,math,re,statistics,hashlib,subprocess
w=Path('/home/jetson/rosdemo_jetson_ws');p=Path(__file__).resolve().parent;src=w/'logs/navigation/manual_left_regression_20261019_191333'
# Functions only consume files and an offline shared library. No ROS or serial imports.
def interp(rows,key,t):
 times=[r['stamp'] for r in rows];i=bisect.bisect_right(times,t)
 assert 0<i<len(rows)
 a,b=rows[i-1:i+1];return a[key]+(b[key]-a[key])*(t-a['stamp'])/(b['stamp']-a['stamp'])
def integral(rows,key,a,b):
 pts=[(a,interp(rows,key,a))]+[(r['stamp'],r[key]) for r in rows if a<r['stamp']<b]+[(b,interp(rows,key,b))]
 return sum((x[1]+y[1])*.5*(y[0]-x[0]) for x,y in zip(pts,pts[1:]))
rows=collections.defaultdict(list)
for line in (src/'motion.jsonl').open():
 r=json.loads(line);rows[r['topic']].append(r)
cmd=rows['/cmd_vel'];start=next(r['stamp'] for r in cmd if r['wz']!=0)
stop=next(r['stamp'] for r in cmd if r['stamp']>start and r['wz']==0);duration=stop-start
js=rows['/joint_states'];wheel=rows['/wheel/odometry'];imu=rows['/imu/data_raw']
for r in js:
 r['cps']=[v*1560/(2*math.pi) for v in r['velocity']]
 for i in range(4):r['cps'+str(i)]=r['cps'][i]
 r['reconstructed_vx']=sum(r['cps'])*.25*math.pi*.065/1560
 r['reconstructed_wz']=((r['cps'][2]+r['cps'][3])-(r['cps'][0]+r['cps'][1]))*.5*math.pi*.065/1560/.395
by_stamp={r['stamp']:r for r in wheel}
matched=[(r,by_stamp[r['stamp']]) for r in js if r['stamp'] in by_stamp]
assert len(matched)>=.99*len(js)
matherr={k:max(abs(a['reconstructed_'+k]-b[k]) for a,b in matched) for k in ['vx','wz']}
assert max(matherr.values())<1e-10
before=max((r for r in js if r['stamp']<start),key=lambda r:r['stamp'])
after=min((r for r in js if r['stamp']>stop+1),key=lambda r:r['stamp'])
counts=[[round(v*1560/(2*math.pi)) for v in r['joint_position']] for r in [before,after]]
delta=[b-a for a,b in zip(*counts)]
countyaw=math.degrees(((delta[2]+delta[3])-(delta[0]+delta[1]))*.5*math.pi*.065/1560/.395)
wheel_yaw_delta=math.degrees(math.remainder(interp(wheel,'yaw',after['stamp'])-interp(wheel,'yaw',before['stamp']),2*math.pi))
assert abs(countyaw-wheel_yaw_delta)<1e-8
raw=[]
for line in (src/'driver.log').read_text().splitlines():
 m=re.search(r'\[INFO\] \[([\d.]+)\].*R4 WHEEL t=(\d+) count=\[([^]]+)\] cps=\[([^]]+)\]',line)
 if m:raw.append({'host_log_s':float(m[1]),'t_ms':int(m[2]),'count':list(map(int,m[3].split(','))),'cps':list(map(int,m[4].split(',')))})
a=max((r for r in raw if r['host_log_s']<start),key=lambda r:r['host_log_s'])
b=min((r for r in raw if r['host_log_s']>stop+1),key=lambda r:r['host_log_s'])
raw_delta=[y-x for x,y in zip(a['count'],b['count'])];assert raw_delta==delta
class V(ctypes.Structure):_fields_=[('vx',ctypes.c_float),('wz',ctypes.c_float)]
class Targets(ctypes.Structure):_fields_=[('cps',ctypes.c_float*4),('left',ctypes.c_float),('right',ctypes.c_float),('scale',ctypes.c_float)]
lib=ctypes.CDLL(str(p/'libkinematics_profile.so'))
lib.ChassisMotionProfile_Step.argtypes=[ctypes.POINTER(V),ctypes.POINTER(V),ctypes.c_uint32,ctypes.POINTER(V)];lib.ChassisMotionProfile_Step.restype=ctypes.c_bool
lib.ChassisKinematics_ToWheelTargets.argtypes=[ctypes.POINTER(V),ctypes.c_float,ctypes.POINTER(Targets)];lib.ChassisKinematics_ToWheelTargets.restype=ctypes.c_bool
v=V();target=V(0,.2);now=0;model=[{'stamp':0.,'wz':0.}]
for ms in range(10,int(duration*1000)+1,10):
 out=V();assert lib.ChassisMotionProfile_Step(ctypes.byref(v),ctypes.byref(target),10,ctypes.byref(out));v=out;now=ms/1000
 model.append({'stamp':now,'wz':float(v.wz)})
model.append({'stamp':duration,'wz':float(v.wz)})
# All motion-profile transients end before the truncated final step.
profile_angle=sum((a['wz']+b['wz'])*.5*(b['stamp']-a['stamp']) for a,b in zip(model,model[1:]))
targets=Targets();assert lib.ChassisKinematics_ToWheelTargets(ctypes.byref(target),1600.,ctypes.byref(targets));assert targets.scale==1.
nominal=abs(float(targets.cps[0]));segments=[]
for lo,hi in [(0,.5),(.5,1.),(1.,1.5),(1.5,duration)]:
 cps=[integral(js,'cps'+str(i),start+lo,start+hi)/(hi-lo) for i in range(4)]
 segments.append({'time_from_command_s':[lo,hi],'time_weighted_mean_filtered_cps':cps,
   'imu_mean_wz_rad_s':integral(imu,'gyro_z',start+lo,start+hi)/(hi-lo),
   'wheel_mean_wz_rad_s':integral(wheel,'wz',start+lo,start+hi)/(hi-lo)})
late=[r for r in js if start+.5<=r['stamp']<=stop]
late_metrics=[]
for i in range(4):
 vals=[abs(r['cps'][i]) for r in late]
 late_metrics.append({'wheel':['LF','LR','RF','RR'][i],'samples':len(vals),
  'mean_abs_filtered_cps':statistics.mean(vals),'median_abs_filtered_cps':statistics.median(vals),'peak_abs_filtered_cps':max(vals),
  'sample_fraction_abs_below_20cps':sum(v<20 for v in vals)/len(vals),
  'mean_fraction_of_inferred_steady_target':statistics.mean(vals)/nominal})
bias=statistics.mean(r['gyro_z'] for r in imu if start-5<=r['stamp']<=start-.5)
motion_angle=math.degrees(integral(imu,'gyro_z',start-.2,stop+1));baseline_angle=math.degrees(bias*(duration+1.2))
# Compare prior same-version trials using the exact same command-boundary definition.
previous=[]
for name in ['low_speed_left_turn_trial','controlled_left_90_trial','ekf_left_turn_trial']:
 f=w/'logs/acceptance/v0184_imu_calibration_20261018_112501'/(name+'.jsonl')
 rr=collections.defaultdict(list)
 for line in f.open():
  r=json.loads(line);rr[r['topic']].append(r)
 c=rr['/cmd_vel'];changes=[];last=None
 for r in c:
  val=(r['vx'],r['wz'])
  if val!=last:changes.append(r);last=val
 acts=[r for r in changes if r['wz']!=0]
 for n,act in enumerate(acts):
  end=next((r['stamp'] for r in changes if r['stamp']>act['stamp'] and r['wz']==0),None)
  if end is None:continue
  lo,hi=act['stamp']-.2,end+1
  if not all(rr[t][0]['stamp']<lo<hi<rr[t][-1]['stamp'] for t in ['/imu/data_raw','/wheel/odometry']):continue
  previous.append({'file':str(f),'segment':n+1,'command_wz':act['wz'],'duration_s':end-act['stamp'],
   'imu_deg':math.degrees(integral(rr['/imu/data_raw'],'gyro_z',lo,hi)),
   'wheel_deg':math.degrees(integral(rr['/wheel/odometry'],'wz',lo,hi))})
r={'scope':'offline replay and host-built production source with mocks; no physical motion, sensor reset, serial access or firmware flash',
 'input_capture':str(src),'command_duration_s':duration,'reference_profile_integral_deg':math.degrees(profile_angle),
 'reference_profile_loss_vs_requested_deg':math.degrees(.2*duration-profile_angle),
 'reference_profile_reaches_0_2_s':next(r['stamp'] for r in model if abs(r['wz']-.2)<1e-6),
 'inferred_steady_wheel_targets_cps':list(targets.cps),'inferred_nominal_encoder_counts_abs_with_profile':profile_angle*.210/2*1560/(math.pi*.065),
 'reference_profile_plus_0_395_effective_track_angle_deg':math.degrees(profile_angle)*.210/.395,
 'wheel_reconstruction_samples':len(matched),'max_ros_wheel_math_abs_error':matherr,
 'joint_relative_encoder_count_before':counts[0],'joint_relative_encoder_count_after':counts[1],'joint_origin_scope':'Joint positions subtract a per-wheel session origin; only their deltas are compared to raw MCU counts','encoder_delta_LF_LR_RF_RR':delta,
 'raw_driver_sparse_log_before':a,'raw_driver_sparse_log_after':b,'raw_driver_sparse_log_encoder_delta':raw_delta,'count_based_wheel_yaw_deg':countyaw,'wheel_pose_yaw_delta_deg':wheel_yaw_delta,
 'imu_motion_integral_deg':motion_angle,'pre_motion_mean_gyro_z_rad_s':bias,'pre_motion_baseline_contribution_deg':baseline_angle,
 'offline_only_baseline_sensitivity_imu_deg':motion_angle-baseline_angle,
 'half_second_segments':segments,'after_first_0_5s_wheel_statistics':late_metrics,
 'historical_same_version_command_window_reanalysis':previous,
 'runtime_model_scope':'Unmodified v0.18.4 runtime/controller with existing mocked peripherals and zero measured velocity; proves logic only, not a physical-plant/PWM measurement',
 'remaining_unknown':'Actual on-board applied/profile command, target, FF/P/I, PWM/saturation/breakaway trace not in this capture',
 'conclusion':'No ROS wheel-unit/track conversion error found; no repeated-ramp-reset under normal repeated-command model. Acceleration and nominal/effective geometry account for part, but not all, of low response. Unequal and low actual encoder counts persist beyond startup; underlying loaded wheel response versus on-board target remains unresolved, not proof of a firmware bug.'}
(p/'offline_analysis.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
with (p/'half_second_response.csv').open('w') as f:
 wr=csv.writer(f);wr.writerow(['from_s','to_s','LF_cps','LR_cps','RF_cps','RR_cps','imu_wz_rad_s','wheel_wz_rad_s'])
 for s in segments:wr.writerow(s['time_from_command_s']+s['time_weighted_mean_filtered_cps']+[s['imu_mean_wz_rad_s'],s['wheel_mean_wz_rad_s']])
print(json.dumps(r,indent=2,ensure_ascii=False))
