from pathlib import Path
import datetime,hashlib,json,subprocess
w=Path('/home/jetson/rosdemo_jetson_ws');ref=Path('/home/jetson/firmware_reference/rosDemo-stm32-chassis-0.18.4')
p=w/'logs/navigation'/datetime.datetime.now().strftime('offline_response_review_%Y%m%d_%H%M%S');p.mkdir()
(w/'logs/navigation/current_offline_response_review_path.txt').write_text(str(p)+'\n')
def call(args,name,cwd=ref):
 r=subprocess.run([str(a) for a in args],cwd=cwd,capture_output=True,text=True)
 (p/name).write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError(f'{name}: {r.returncode}: {r.stdout}{r.stderr}')
 return r.stdout
call(['git','status','--short'],'reference_git_before.txt')
base=['gcc','-std=c11','-Wall','-Wextra','-Werror','-ITools/tests/imu_spi_probe/stubs','-IApplication/Chassis','-IApplication/Safety','-IApplication/Services','-IApplication/Diagnostics']
core=['Application/Chassis/chassis_motion_profile.c','Application/Chassis/wheel_speed_controller.c','Application/Safety/fault_manager.c','Application/Services/control_timing.c']
runtime=['Application/Chassis/chassis_runtime.c','Application/Chassis/chassis_controller.c','Application/Chassis/chassis_kinematics.c','Application/Chassis/chassis_motion_profile.c','Application/Chassis/wheel_speed_controller.c','Application/Diagnostics/motion_trace.c']
commands=[]
for name,test,sources in [('motion_core','Tools/tests/motion/test_motion_core.c',core),('runtime_motion','Tools/tests/motion/test_runtime_motion.c',runtime)]:
 cmd=base+[test]+sources+['-lm','-o',p/name];commands.append([str(x) for x in cmd]);call(cmd,name+'_build.log');call([p/name],name+'_test.log')
harness=p/'pivot_runtime_probe.c'
harness.write_text('''/* OFFLINE ONLY: actual runtime + reference test mocks; no physical-plant model. */
#define main ReferenceRuntimeRegressionMain
#include "'''+str(ref/'Tools/tests/motion/test_runtime_motion.c')+'''"
#undef main
int main(void)
{
  puts("sign,t_ms,requested_wz,applied_wz,target_lf,target_lr,target_rf,target_rr,scale");
  for (int sign=-1; sign<=1; sign+=2) {
    Init(0U);
    for (time_ms=10U; time_ms<=2110U; time_ms+=10U) {
      if ((time_ms-10U)%50U==0U)
        assert(ChassisRuntime_SetVelocity(0.0f,0.2f*(float)sign,time_ms));
      ChassisRuntime_Process(time_ms,false);
      ChassisRuntimeStatus s=Status(); ChassisControllerStatus c;
      assert(ChassisController_GetStatus(&c));
      assert(s.state==CHASSIS_RUNTIME_STATE_ACTIVE);
      if (time_ms>=140U) assert(fabsf(s.applied_command.angular_z_rad_s-0.2f*(float)sign)<1e-6f);
      assert(c.targets.scale==1.0f);
      printf("%d,%u,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f\\n", sign,(unsigned)time_ms,
        (double)s.requested_command.angular_z_rad_s,(double)s.applied_command.angular_z_rad_s,
        (double)c.targets.counts_per_second[0],(double)c.targets.counts_per_second[1],
        (double)c.targets.counts_per_second[2],(double)c.targets.counts_per_second[3],(double)c.targets.scale);
    }
    ChassisRuntime_Stop(2111U); AssertStopped(CHASSIS_RUNTIME_STOP_EXPLICIT);
  }
  return 0;
}
''')
cmd=base+[harness]+runtime+['-lm','-o',p/'pivot_runtime_probe'];commands.append([str(x) for x in cmd]);call(cmd,'pivot_runtime_probe_build.log');call([p/'pivot_runtime_probe'],'pivot_runtime_model.csv')
cmd=['gcc','-std=c11','-Wall','-Wextra','-Werror','-shared','-fPIC','-IApplication/Chassis','Application/Chassis/chassis_motion_profile.c','Application/Chassis/chassis_kinematics.c','-lm','-o',p/'libkinematics_profile.so'];commands.append([str(x) for x in cmd]);call(cmd,'kinematics_profile_build.log')
for name in ['test_velocity_command','test_odometry']:
 cmd=['bash','-c','source /opt/ros/humble/setup.bash && '+str(w/'build/rosdemo_base'/name)]
 commands.append(cmd);call(cmd,name+'.log',w)
(p/'commands.json').write_text(json.dumps({'scope':'offline only; no serial, ROS publishers, calibration, firmware build/flash or physical motion','cwd_firmware_reference':str(ref),'commands':commands},indent=2)+'\n')
print(p)
