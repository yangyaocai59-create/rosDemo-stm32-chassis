"""Save the static-validated driver checkpoint without commanding motion."""
import datetime
import hashlib
import json
import math
import shutil
import tarfile
import time
from pathlib import Path

import rclpy
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Imu, LaserScan
from tf2_msgs.msg import TFMessage
from rclpy.qos import qos_profile_sensor_data

workspace = Path('/home/jetson/rosdemo_jetson_ws')
base = Path('/home/jetson/rosdemo_checkpoints')
evidence = Path(__file__).parent
old = Path((base/'active_checkpoint_path.txt').read_text().strip())
manifest = json.loads((old / 'manifest.json').read_text())

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

changed = [row['path'] for row in manifest['critical_files']
           if sha(Path(row['path'])) != row['sha256']]
assert changed == [], changed
rclpy.init()
node = rclpy.create_node('accepted_checkpoint_capture')
counts = {'wheel': 0, 'scan': 0, 'imu': 0}
transforms = {}
max_speed = [0.0]
start = time.monotonic() + 2

def receive(key, msg):
    if time.monotonic() < start:
        return
    counts[key] += 1
    if key == 'wheel':
        max_speed[0] = max(max_speed[0], abs(msg.twist.twist.linear.x),
                           abs(msg.twist.twist.angular.z))

def tf_callback(msg):
    for transform in msg.transforms:
        edge = (transform.header.frame_id, transform.child_frame_id)
        if edge in [('map', 'odom'), ('odom', 'base_footprint')]:
            transforms[edge] = transform.transform

subscriptions = [
    node.create_subscription(Odometry, '/wheel/odometry', lambda m: receive('wheel', m), 50),
    node.create_subscription(LaserScan, '/scan', lambda m: receive('scan', m), qos_profile_sensor_data),
    node.create_subscription(Imu, '/imu/data_raw', lambda m: receive('imu', m), qos_profile_sensor_data),
    node.create_subscription(TFMessage, '/tf', tf_callback, 100),
]
while time.monotonic() - start < 5:
    rclpy.spin_once(node, timeout_sec=.05)
publishers = node.count_publishers('/cmd_vel')
node.destroy_node()
rclpy.try_shutdown()
assert publishers == 0 and max_speed[0] == 0.0 and min(counts.values()) >= 30

def yaw(q):
    return math.atan2(2*(q.w*q.z + q.x*q.y), 1-2*(q.y*q.y + q.z*q.z))

a = transforms[('map', 'odom')]
b = transforms[('odom', 'base_footprint')]
t = yaw(a.rotation)
pose = [a.translation.x + math.cos(t)*b.translation.x - math.sin(t)*b.translation.y,
        a.translation.y + math.sin(t)*b.translation.x + math.cos(t)*b.translation.y,
        t + yaw(b.rotation)]


print(json.dumps({"map_pose":pose,"counts":counts,"max_wheel_speed":max_speed[0],"cmd_publishers":publishers,"scope":"read-only 5s after discovery; no checkpoint updated"},indent=2))
